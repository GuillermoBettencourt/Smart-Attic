# Smart-Attic
Smart Attic for Intelligent Ambient course at IST
